"""Compare fixed covariance variants on the nonempty PSD frontend."""
from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
import json
from pathlib import Path
import sys

import numpy as np
from sklearn.covariance import LedoitWolf
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits

PC = Path(__file__).resolve().parents[1]
ROOT = PC.parent
sys.path.insert(0, str(PC))
from tools import evaluate_canonical as canonical
from tools import evaluate_psd_nonempty as psd

PLAN = ROOT / "results/psd_covariance/2026-09-07/plan.json"
METHODS = ("ledoit_wolf", "eigen_floor_100", "diagonal_blend_010", "scale_floor_q25")


def fit_models(source, plan):
    mean = source.mean(axis=0)
    raw_scale = source.std(axis=0)
    scale = np.where(raw_scale < 1e-8, 1.0, raw_scale)
    fitted = LedoitWolf().fit((source - mean) / scale)
    covariance = fitted.covariance_
    eigenvalues, basis = np.linalg.eigh(covariance)
    floor = eigenvalues[-1] / plan["eigen_max_condition"]
    floored = (basis * np.maximum(eigenvalues, floor)) @ basis.T
    alpha = plan["diagonal_blend"]
    blended = (1-alpha) * covariance + alpha * np.diag(np.diag(covariance))
    scale_floor = float(np.quantile(raw_scale, plan["source_scale_floor_quantile"]))
    limited_scale = np.maximum(scale, scale_floor)
    limited_fit = LedoitWolf().fit((source - mean) / limited_scale)
    models = {
        METHODS[0]: canonical.StatisticalModel(mean, scale, fitted.precision_),
        METHODS[1]: canonical.StatisticalModel(mean, scale, np.linalg.inv(floored)),
        METHODS[2]: canonical.StatisticalModel(mean, scale, np.linalg.inv(blended)),
        METHODS[3]: canonical.StatisticalModel(mean, limited_scale, limited_fit.precision_),
    }
    diagnostics = {}
    for name, model in models.items():
        precision = (model.precision + model.precision.T) / 2
        model.precision[:] = precision
        eigen64 = np.linalg.eigvalsh(precision)
        eigen32 = np.linalg.eigvalsh(precision.astype(np.float32).astype(np.float64))
        if eigen64[0] <= 0 or eigen32[0] <= 0:
            raise ValueError(f"non-positive precision: {name}")
        diagnostics[name] = {
            "condition": float(eigen64[-1] / eigen64[0]),
            "precision_min_eigenvalue": float(eigen64[0]),
            "precision_max_eigenvalue": float(eigen64[-1]),
            "float32_precision_min_eigenvalue": float(eigen32[0]),
            "scale_min": float(model.source_scale.min()),
            "scale_max": float(model.source_scale.max()),
        }
    diagnostics["source_fit"] = {
        "ledoit_wolf_shrinkage": float(fitted.shrinkage_),
        "limited_scale_shrinkage": float(limited_fit.shrinkage_),
        "source_scale_floor": scale_floor,
        "floored_scale_components": int(np.sum(scale < scale_floor)),
        "covariance_eigen_floor": float(floor),
        "floored_eigenvalues": int(np.sum(eigenvalues < floor)),
    }
    return models, diagnostics


def evaluate_normal(models, normal, manifests, quantile):
    rows = []
    for name, model in models.items():
        z = model.transform(normal)
        for k, manifest in manifests.items():
            for split in manifest["machines"]["fan"]["splits"]:
                cal, held = split["calibration_pool_indices"], split["held_out_normal_pool_indices"]
                center = z[cal].mean(axis=0)
                cal_scores = canonical.mahalanobis(z[cal], center, model.precision)
                loo_scores = cal_scores * (len(cal) / (len(cal)-1))**2
                held_scores = canonical.mahalanobis(z[held], center, model.precision)
                threshold = float(np.quantile(cal_scores, quantile, method="higher"))
                median = float(np.median(held_scores))
                high = float(np.quantile(held_scores, quantile, method="higher"))
                rows.append(dict(method=name, k=k, split=split["calibration_split_id"],
                    cal_raw_loo_cv=float(loo_scores.std(ddof=1) / max(loo_scores.mean(), 1e-12)),
                    normal_median=median, normal_q99=high,
                    normal_q99_median_ratio=high / max(median, 1e-12),
                    diagnostic_cal_q99=threshold,
                    diagnostic_held_normal_exceedance=float(np.mean(held_scores > threshold))))
    return rows


def evaluate_anomalies(models, normal, anomaly, manifests, rows):
    indexed = {(r["method"], r["k"], r["split"]): r for r in rows}
    for name, model in models.items():
        normal_z, anomaly_z = model.transform(normal), model.transform(anomaly)
        for k, manifest in manifests.items():
            for split in manifest["machines"]["fan"]["splits"]:
                cal, held = split["calibration_pool_indices"], split["held_out_normal_pool_indices"]
                center = normal_z[cal].mean(axis=0)
                normal_scores = canonical.mahalanobis(normal_z[held], center, model.precision)
                anomaly_scores = canonical.mahalanobis(anomaly_z, center, model.precision)
                labels = np.r_[np.zeros(len(held)), np.ones(len(anomaly))]
                scores = np.r_[normal_scores, anomaly_scores]
                row = indexed[name, k, split["calibration_split_id"]]
                row.update(auc=float(roc_auc_score(labels, scores)),
                    pauc=float(roc_auc_score(labels, scores, max_fpr=0.1)),
                    diagnostic_anomaly_response=float(np.mean(anomaly_scores > row["diagnostic_cal_q99"])))


def run(args):
    output = args.output.resolve()
    if output.exists():
        raise ValueError("choose a fresh output directory")
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    if plan["candidates"] != list(METHODS):
        raise ValueError("method list differs from plan")
    output.mkdir(parents=True)
    (output / "plan.json").write_bytes(PLAN.read_bytes())
    plan_hash = psd.sha(PLAN)
    dataset = args.data_root.resolve()
    cohorts = psd.discover(dataset)
    audit = canonical.PhaseAudit()
    manifests = {k: canonical.build_split_manifest({"fan": cohorts}, k=k,
        n_splits=plan["splits"], split_random_state=plan["split_random_state"]) for k in plan["k"]}
    for k, manifest in manifests.items():
        reference = json.loads((ROOT / f"results/psd_nonempty/2026-09-07/splits_k{k}.json").read_text())
        if manifest["content_sha256"] != reference["content_sha256"]:
            raise ValueError("input clips or paired splits differ from the previous study")
    source = psd.features(psd.extract(dataset, cohorts.source_fit, audit, "source normal")[:, 1])
    normal = psd.features(psd.extract(dataset, cohorts.target_normal_pool, audit, "target normal")[:, 1])
    models, fit_diagnostics = fit_models(source, plan)
    reference_path = ROOT / "results/psd_nonempty/2026-09-07/nonempty_log96_model.npz"
    with np.load(reference_path) as old:
        for key, value in asdict(models[METHODS[0]]).items():
            np.testing.assert_allclose(value, old[key], rtol=1e-10, atol=1e-10)
    rows = evaluate_normal(models, normal, manifests, plan["normal_diagnostic_quantile"])
    psd.write_json(output / "normal_only.json", rows)
    for name, model in models.items():
        np.savez_compressed(output / f"{name}.npz", **asdict(model))
    frozen = dict(plan_sha256=plan_hash, target_anomaly_feature_reads=audit.target_anomaly_feature_reads,
        models={name: psd.sha(output / f"{name}.npz") for name in models},
        normal_diagnostics_sha256=psd.sha(output / "normal_only.json"),
        split_manifests={k: m["content_sha256"] for k, m in manifests.items()},
        source_hashes={p.relative_to(ROOT).as_posix(): psd.sha(p) for p in
            (Path(__file__), PC / "tools/evaluate_psd_nonempty.py", PC / "tools/evaluate_canonical.py")})
    assert frozen["target_anomaly_feature_reads"] == 0
    psd.write_json(output / "frozen.json", frozen)
    print("normal diagnostics and all models frozen; reading anomalies", flush=True)
    if psd.sha(PLAN) != plan_hash:
        raise ValueError("plan changed")
    audit.enter_evaluate()
    anomaly = psd.features(psd.extract(dataset, cohorts.target_anomaly_evaluate, audit, "target anomaly")[:, 1])
    evaluate_anomalies(models, normal, anomaly, manifests, rows)
    for name, expected in frozen["models"].items():
        assert psd.sha(output / f"{name}.npz") == expected
    with (output / "per_split.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    metrics = ("auc", "pauc", "cal_raw_loo_cv", "normal_median", "normal_q99", "normal_q99_median_ratio",
               "diagnostic_held_normal_exceedance", "diagnostic_anomaly_response")
    aggregates, paired = [], []
    for k in plan["k"]:
        baseline = [r for r in rows if r["method"] == METHODS[0] and r["k"] == k]
        for name in models:
            group = [r for r in rows if r["method"] == name and r["k"] == k]
            aggregates.append(dict(method=name, k=k, **{
                f"{metric}_{stat}": float(fn([r[metric] for r in group]))
                for metric in metrics for stat, fn in (("mean", np.mean), ("std", np.std))}))
            for metric in ("auc", "pauc", "cal_raw_loo_cv", "normal_q99_median_ratio", "diagnostic_held_normal_exceedance"):
                delta = np.array([a[metric]-b[metric] for a, b in zip(group, baseline)])
                paired.append(dict(method=name, k=k, metric=metric,
                    mean_delta=float(delta.mean()), min_delta=float(delta.min()),
                    max_delta=float(delta.max()), positive_splits=int(np.sum(delta > 0))))
    summary = dict(protocol=plan["protocol"], fit_diagnostics=fit_diagnostics,
        cohort_counts=dict(source_normal=len(source), target_normal=len(normal), target_anomaly=len(anomaly)),
        aggregates=aggregates, paired_deltas=paired, dependencies=canonical.dependency_versions(),
        physical_validation=False, firmware_model_changed=False,
        calibration_replay=False, independent_evaluation=False)
    psd.write_json(output / "summary.json", summary)
    print(json.dumps(dict(fit_diagnostics=fit_diagnostics, aggregates=aggregates), indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    with threadpool_limits(limits=1):
        run(parser.parse_args())
