"""Compare one nonempty PSD map with the existing map on paired fan splits."""
from __future__ import annotations

import argparse
import csv
import ctypes
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from dataclasses import asdict
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import welch
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits

PC = Path(__file__).resolve().parents[1]
ROOT = PC.parent
sys.path.insert(0, str(PC))
from asd import data
from tools import evaluate_canonical as canonical

METHODS = ("baseline_log96", "nonempty_log96")
GAINS = (0.25, 0.5, 1.0, 2.0, 4.0)
SOURCE = ROOT / "firmware/esp32s3_asd/main/psd_features_c.c"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def edges(nonempty=False):
    nominal = np.ceil(np.geomspace(10.0, 4000.0, 97) * 8192 / 16000).astype(int)
    if nonempty:
        for i in range(1, len(nominal)):
            nominal[i] = max(nominal[i], nominal[i-1] + 1)
    return nominal


def band_power(signal):
    signal = np.asarray(signal, np.float64)
    signal = signal - signal.mean()
    _, power = welch(signal, fs=16000, window="hann", nperseg=8192,
                     noverlap=4096, detrend=False, scaling="spectrum")
    result = []
    for nonempty in (False, True):
        bounds = edges(nonempty)
        result.append(np.array([power[a:b].mean() if b > a else 0.0
                                for a, b in zip(bounds[:-1], bounds[1:])]))
    return np.stack(result)


def features(power, gain=1.0):
    logs = np.log10(np.asarray(power) * gain**2 + 1e-20)
    return logs - logs.mean(axis=-1, keepdims=True)


def read_audio(path):
    signal, sr = sf.read(path, dtype="float32", always_2d=True)
    if sr != 16000 or len(signal) != 160000:
        raise ValueError(f"expected 10 s at 16 kHz: {path.name}")
    return np.ascontiguousarray(signal[:, 0])


def discover(dataset):
    train = data.list_clips(dataset / "fan", "train")
    test = data.list_clips(dataset / "fan", "test")

    def refs(clips, split):
        return tuple(canonical.ClipRef(
            c.path.relative_to(dataset).as_posix(), split, c.domain, c.label,
            c.path.stat().st_size, sha(c.path)) for c in clips)

    train_refs, test_refs = refs(train, "train"), refs(test, "test")
    cohorts = canonical.MachineCohorts(
        tuple(c for c in train_refs if c.domain == "source" and c.label == 0),
        tuple(c for c in train_refs + test_refs if c.domain == "target" and c.label == 0),
        tuple(c for c in test_refs if c.domain == "target" and c.label == 1))
    canonical.validate_cohorts(cohorts)
    return cohorts


def extract(dataset, clips, audit, label):
    audit.record_feature_read(clips)
    values = []
    for i, clip in enumerate(clips, 1):
        path = dataset / clip.relative_path
        if sha(path) != clip.content_sha256:
            raise RuntimeError(f"input changed: {clip.relative_path}")
        values.append(band_power(read_audio(path)))
        if i % 100 == 0 or i == len(clips):
            print(f"{label}: {i}/{len(clips)}", flush=True)
    return np.stack(values)


def load_c(path):
    lib = ctypes.CDLL(str(path))
    ptr = ctypes.POINTER(ctypes.c_float)
    lib.asd_psd_init()
    lib.asd_psd_extract.argtypes = [ptr, ctypes.c_int, ptr]
    lib.asd_psd_extract.restype = ctypes.c_int
    lib.asd_psd_score.argtypes = [ptr, ptr, ptr, ptr, ptr, ctypes.c_int]
    lib.asd_psd_score.restype = ctypes.c_float
    lib.asd_psd_stream_push_hop.argtypes = [ptr]
    lib.asd_psd_stream_finish.argtypes = [ptr]
    lib.asd_psd_stream_finish.restype = ctypes.c_int
    return lib


def unload_c(lib):
    if sys.platform == "win32":
        ctypes.windll.kernel32.FreeLibrary.argtypes = [ctypes.c_void_p]
        ctypes.windll.kernel32.FreeLibrary(lib._handle)


def c_feature(lib, signal):
    signal = np.ascontiguousarray(signal, np.float32)
    out = np.empty(96, np.float32)
    ptr = ctypes.POINTER(ctypes.c_float)
    segments = lib.asd_psd_extract(signal.ctypes.data_as(ptr), len(signal), out.ctypes.data_as(ptr))
    if segments != 38:
        raise RuntimeError(f"unexpected segment count: {segments}")
    return out


def verify_c(dataset, normal_clips, models):
    cc = shutil.which("gcc")
    if not cc:
        raise RuntimeError("gcc is required")
    rng = np.random.default_rng(20260907)
    signals = [("broadband", rng.uniform(-0.1, 0.1, 160000).astype(np.float32))]
    signals += [(c.relative_path, read_audio(dataset / c.relative_path)) for c in normal_clips]
    records = []
    with tempfile.TemporaryDirectory(prefix="psd-nonempty-") as temp:
        for method_index, method in enumerate(METHODS):
            dll = Path(temp) / (method + ".dll")
            command = [cc, "-O2", "-shared", "-o", str(dll), str(SOURCE), f"-I{SOURCE.parent}"]
            if method_index:
                command += ["-DASD_PSD_NONEMPTY_BANDS=1"]
            subprocess.run(command, check=True, capture_output=True)
            lib = load_c(dll)
            try:
                for label, signal in signals:
                    ref_power = band_power(signal)[method_index]
                    at_one = c_feature(lib, signal)
                    max_reference_error = 0.0
                    gain_errors = {}
                    for gain in GAINS:
                        got = c_feature(lib, signal * gain)
                        ref = features(ref_power, gain)
                        max_reference_error = max(max_reference_error, float(np.max(np.abs(got-ref))))
                        gain_errors[str(gain)] = float(np.max(np.abs(got-at_one)))
                    # the same map must serve batch, streaming and sidecar paths
                    ptr = ctypes.POINTER(ctypes.c_float)
                    lib.asd_psd_stream_reset()
                    for start in range(0, len(signal)-4096+1, 4096):
                        hop = np.ascontiguousarray(signal[start:start+4096], np.float32)
                        lib.asd_psd_stream_push_hop(hop.ctypes.data_as(ptr))
                    stream = np.empty(96, np.float32)
                    assert lib.asd_psd_stream_finish(stream.ctypes.data_as(ptr)) == 38
                    model = models[method]
                    arrays = [np.ascontiguousarray(a, np.float32) for a in
                              (at_one, model.source_mean, model.source_scale,
                               model.precision, np.zeros(96))]
                    score_c = lib.asd_psd_score(*(a.ctypes.data_as(ptr) for a in arrays), 96)
                    delta = ((arrays[0] - arrays[1]) / arrays[2]).astype(np.float64)
                    score_pc = float(delta @ arrays[3].astype(np.float64) @ delta)
                    records.append(dict(method=method, signal=label,
                        gain_max_abs_feature_change=gain_errors,
                        max_pc_c_feature_error=max_reference_error,
                        batch_stream_max_abs_error=float(np.max(np.abs(at_one-stream))),
                        score_relative_error=abs(score_c-score_pc)/max(abs(score_pc), 1e-12)))
            finally:
                unload_c(lib)
    return records


def evaluate(models, normal_power, anomaly_power, manifests):
    rows = []
    gain_summary = {}
    for m, name in enumerate(METHODS):
        model = models[name]
        normal_at_one = model.transform(features(normal_power[:, m]))
        gain_summary[name] = {}
        for gain in GAINS:
            normal_z = model.transform(features(normal_power[:, m], gain))
            anomaly_z = model.transform(features(anomaly_power[:, m], gain))
            nq = canonical.QuadraticScoreCache.build(normal_z, model.precision)
            aq = canonical.QuadraticScoreCache.build(anomaly_z, model.precision)
            gain_summary[name][str(gain)] = float(np.max(np.abs(
                features(normal_power[:, m], gain) - features(normal_power[:, m]))))
            for k, manifest in manifests.items():
                for split in manifest["machines"]["fan"]["splits"]:
                    cal, held = split["calibration_pool_indices"], split["held_out_normal_pool_indices"]
                    center = normal_at_one[cal].mean(axis=0)
                    held_scores = nq.scores_from_center(center)[held]
                    anomaly_scores = aq.scores_from_center(center)
                    labels = np.r_[np.zeros(len(held)), np.ones(len(anomaly_z))]
                    scores = np.r_[held_scores, anomaly_scores]
                    rows.append(dict(method=name, k=k, gain=gain,
                        split=split["calibration_split_id"],
                        auc=float(roc_auc_score(labels, scores)),
                        pauc=float(roc_auc_score(labels, scores, max_fpr=0.1)),
                        normal_score_median=float(np.median(held_scores))))
    return rows, gain_summary


def run(args):
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if (output / "summary.json").exists():
        raise RuntimeError("choose a fresh output directory; existing results are retained")
    plan_path = ROOT / "results/psd_nonempty/2026-09-07/plan.json"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if plan["candidates"] != list(METHODS) or plan["amplitude_gains"] != list(GAINS):
        raise RuntimeError("code differs from the frozen plan")
    plan_hash = sha(plan_path)
    dataset = args.data_root.resolve()
    cohorts = discover(dataset)
    audit = canonical.PhaseAudit()
    manifests = {k: canonical.build_split_manifest({"fan": cohorts}, k=k,
        n_splits=plan["splits"], split_random_state=plan["split_random_state"]) for k in (10, 20)}
    for k, manifest in manifests.items():
        write_json(output / f"splits_k{k}.json", manifest)
    source = extract(dataset, cohorts.source_fit, audit, "source normal")
    normal = extract(dataset, cohorts.target_normal_pool, audit, "target normal")
    models = {name: canonical.fit_source_only(features(source[:, m])) for m, name in enumerate(METHODS)}
    for name, model in models.items():
        np.savez_compressed(output / f"{name}_model.npz", **asdict(model))
    bands = {name: dict(edges=edges(bool(m)).tolist(), counts=np.diff(edges(bool(m))).tolist())
             for m, name in enumerate(METHODS)}
    write_json(output / "bands.json", bands)
    frozen = dict(plan_sha256=plan_hash, target_anomaly_feature_reads=audit.target_anomaly_feature_reads,
        models={name: sha(output / f"{name}_model.npz") for name in METHODS},
        split_manifests={k: manifest["content_sha256"] for k, manifest in manifests.items()},
        band_map_sha256=sha(output / "bands.json"),
        source_hashes={p.relative_to(ROOT).as_posix(): sha(p) for p in
            (Path(__file__), SOURCE, PC / "tools/evaluate_canonical.py")})
    assert frozen["target_anomaly_feature_reads"] == 0
    write_json(output / "frozen.json", frozen)
    print("models and paired splits frozen; checking C on normal signals", flush=True)
    c_checks = verify_c(dataset, cohorts.source_fit[:3] + cohorts.target_normal_pool[:3], models)
    write_json(output / "c_checks.json", c_checks)
    if sha(plan_path) != plan_hash or any(sha(output / f"{n}_model.npz") != h for n,h in frozen["models"].items()):
        raise RuntimeError("frozen inputs changed before target readout")
    audit.enter_evaluate()
    anomaly = extract(dataset, cohorts.target_anomaly_evaluate, audit, "target anomaly readout")
    rows, gains = evaluate(models, normal, anomaly, manifests)
    with (output / "per_split.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    aggregates = []
    for name in METHODS:
        for k in (10, 20):
            for gain in GAINS:
                group = [r for r in rows if (r["method"], r["k"], r["gain"]) == (name,k,gain)]
                aggregates.append(dict(method=name, k=k, gain=gain,
                    **{f"{metric}_{stat}": float(fn([r[metric] for r in group]))
                       for metric in ("auc", "pauc", "normal_score_median")
                       for stat,fn in (("mean",np.mean),("std",np.std))}))
    paired = []
    for k in (10,20):
        for metric in ("auc","pauc"):
            a = np.array([r[metric] for r in rows if (r["method"],r["k"],r["gain"]) == (METHODS[0],k,1.0)])
            b = np.array([r[metric] for r in rows if (r["method"],r["k"],r["gain"]) == (METHODS[1],k,1.0)])
            d = b-a
            paired.append(dict(k=k, metric=metric, mean_delta=float(d.mean()),
                split_delta_std=float(d.std()), min_delta=float(d.min()), max_delta=float(d.max()),
                positive_splits=int(np.sum(d>0)), total_splits=len(d)))
    primary = {p["metric"]: p["mean_delta"] for p in paired if p["k"] == 10}
    limits = plan["offline_screen"]
    candidate_noise = next(r for r in c_checks if r["method"] == METHODS[1] and r["signal"] == "broadband")
    numerical = all(r["max_pc_c_feature_error"] < 2e-3
        and r["batch_stream_max_abs_error"] == 0.0 and r["score_relative_error"] < 1e-4 for r in c_checks)
    screen = numerical and max(candidate_noise["gain_max_abs_feature_change"].values()) < limits["max_broadband_c_feature_gain_error"]
    screen = screen and primary["auc"] >= -limits["max_auc_mean_drop_at_k10"] and primary["pauc"] >= -limits["max_standardized_pauc_mean_drop_at_k10"]
    summary = dict(protocol=plan["protocol"], plan_sha256=plan_hash,
        base_commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
        dependencies=canonical.dependency_versions(),
        cohort_counts=dict(source_normal=len(source), target_normal=len(normal), target_anomaly=len(anomaly)),
        target_anomaly_feature_reads=audit.target_anomaly_feature_reads,
        aggregates=aggregates, paired_deltas=paired, normal_feature_gain_max_abs=gains,
        c_numerical_checks_pass=numerical, offline_screen_pass=bool(screen),
        limitations=plan["limitations"], hardware_tested=False, firmware_image_created=False,
        uncertainty="split dispersion reuses clips; not independent machines or a population confidence interval")
    write_json(output / "summary.json", summary)
    print(json.dumps({k:summary[k] for k in ("cohort_counts","paired_deltas","c_numerical_checks_pass","offline_screen_pass")}, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    with threadpool_limits(limits=1):
        run(args)


if __name__ == "__main__":
    main()
